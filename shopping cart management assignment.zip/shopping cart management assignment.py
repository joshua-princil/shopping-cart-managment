import mysql.connector

class Entity:
    def __init__(self, id):
        self.id = id

    def display_info(self):
        print(f"ID: {self.id}")

class User(Entity):
    def __init__(self, id, username, password):
        super().__init__(id)
        self.username = username
        self.password = password

    def display_info(self):
        super().display_info()
        print(f"Username: {self.username}")

class Product(Entity):
    def __init__(self, id, name, price, stock_quantity):
        super().__init__(id)
        self.name = name
        self.price = price
        self.stock_quantity = stock_quantity

    def display_info(self):
        super().display_info()
        print(f"Name: {self.name}, Price: ${self.price}")

class CartItem(Entity):
    def __init__(self, id, product_id, quantity, price, total_price):
        super().__init__(id)
        self.product_id = product_id
        self.quantity = quantity
        self.price = price
        self.total_price = total_price

    def display_info(self):
        super().display_info()
        print(f"Product ID: {self.product_id}, Quantity: {self.quantity}, Total Price: ${self.total_price}")

class ShoppingCartService:
    def __init__(self):
        self.conn = mysql.connector.connect(
            host="localhost",
            user="yourusername",
            password="yourpassword",
            database="yourdatabasename"
        )
        self.cursor = self.conn.cursor()

    def sign_in(self, username, password):
        # Authenticate user
        self.cursor.execute("SELECT id, username, password FROM Users WHERE username = %s AND password = %s", (username, password))
        user_data = self.cursor.fetchone()
        if user_data:
            return User(user_data[0], user_data[1], user_data[2])
        else:
            return None

    def sign_up(self, username, password):
        # Check if username already exists
        self.cursor.execute("SELECT COUNT(*) FROM Users WHERE username = %s", (username,))
        count = self.cursor.fetchone()[0]
        if count > 0:
            print("Username already exists. Please choose a different username.")
            return False
        else:
            # Create new user
            self.cursor.execute("INSERT INTO Users (username, password) VALUES (%s, %s)", (username, password))
            self.conn.commit()
            print("User created successfully! Please sign in.")
            return True

    def add_to_cart(self, user_id, product_id, quantity):
        self.cursor.execute("""
            SELECT price FROM Products WHERE id = %s
        """, (product_id,))
        price = self.cursor.fetchone()[0]
        
        # Check if the entry already exists in the cart
        self.cursor.execute("""
            SELECT id, quantity, total_price
            FROM cart
            WHERE user_id = %s AND product_id = %s
        """, (user_id, product_id))
        existing_entry = self.cursor.fetchone()

        if existing_entry:
            # Update the existing entry
            new_quantity = existing_entry[1] + quantity
            new_total_price = existing_entry[2] + (quantity * price)
            self.cursor.execute("""
                UPDATE cart
                SET quantity = %s, total_price = %s
                WHERE id = %s
            """, (new_quantity, new_total_price, existing_entry[0]))
        else:
            # Insert a new entry
            self.cursor.execute("""
                INSERT INTO cart (user_id, product_id, quantity, total_price)
                VALUES (%s, %s, %s, %s)
            """, (user_id, product_id, quantity, quantity * price))
        self.conn.commit()


    def remove_from_cart(self, user_id, item_id):
        self.cursor.execute("SELECT id FROM cart WHERE id = %s AND user_id = %s", (item_id, user_id))
        existing_item = self.cursor.fetchone()
        if existing_item:
            self.cursor.execute("DELETE FROM cart WHERE id = %s AND user_id = %s", (item_id, user_id))
            self.conn.commit()
            print("Item removed from cart successfully!")
        else:
            print("Item not found in cart.")

    def get_products(self):
        # Retrieve products from database
        self.cursor.execute("SELECT id, name, price, stock_quantity FROM Products")
        products = []
        for row in self.cursor.fetchall():
            products.append(Product(row[0], row[1], row[2], row[3]))
        return products

    def get_cart_items(self, user_id):
        # Retrieve cart items for a user
        self.cursor.execute("""
            SELECT Cart.id, Cart.product_id, Cart.quantity, Products.price, Cart.quantity * Products.price AS total_price
            FROM Cart
            JOIN Products ON Cart.product_id = Products.id
            WHERE user_id = %s
        """, (user_id,))
        cart_items = []
        for row in self.cursor.fetchall():
            item_id, product_id, quantity, price, total_price = row
            cart_items.append(CartItem(item_id, product_id, quantity, price, total_price))
        return cart_items

    def delete_user(self, user_id):
        # Delete user from database
        self.cursor.execute("DELETE FROM Users WHERE id = %s", (user_id,))
        self.conn.commit()
        print("User deleted successfully.")

    def __del__(self):
        self.conn.close()

def main():
    service = ShoppingCartService()
    print("Welcome to the Shopping Cart System!")

    while True:
        print("\n1. Sign in")
        print("2. Sign up")
        print("3. Delete user information")
        print("4. Exit")
        choice = input("Please choose an option (1/2/3/4): ")

        if choice == '1':
            username = input("Enter your username: ")
            password = input("Enter your password: ")
            user = service.sign_in(username, password)
            if user:
                print(f"Welcome, {user.username}!")
                while True:
                    products = service.get_products()
                    print("\nAvailable Products:")
                    for product in products:
                        product.display_info()

                    print("\n1. Add to cart")
                    print("2. Remove from cart")
                    print("3. Display cart")
                    print("4. Sign out")
                    print("5. Exit")
                    choice = input("Please choose an option (1/2/3/4/5): ")

                    if choice == '1':
                        product_id = int(input("Enter the ID of the product you want to add to the cart: "))
                        quantity = int(input("Enter the quantity: "))
                        service.add_to_cart(user.id, product_id, quantity)
                    elif choice == '2':
                        cart_items = service.get_cart_items(user.id)
                        print("\nYour Cart:")
                        for item in cart_items:
                            item.display_info()
                        item_id = int(input("Enter the ID of the item you want to remove from the cart: "))
                        service.remove_from_cart(user.id, item_id)
                    elif choice == '3':
                        cart_items = service.get_cart_items(user.id)
                        if not cart_items:
                            print("Your cart is empty.")
                        else:
                            print("\nYour Cart:")
                            for item in cart_items:
                                item.display_info()
                    elif choice == '4':
                        print("Goodbye!")
                        break
                    elif choice == '5':
                        print("Goodbye!")
                        return
                    else:
                        print("Invalid choice. Please try again.")
            else:
                print("Invalid username or password.")
        elif choice == '2':
            username = input("Enter your desired username: ")
            password = input("Enter your desired password: ")
            service.sign_up(username, password)
        elif choice == '3':
            confirm = input("Are you sure you want to delete your information? (yes/no): ")
            if confirm.lower() == "yes":
                username = input("Enter your username: ")
                password = input("Enter your password: ")
                user = service.sign_in(username, password)
                if user:
                    service.delete_user(user.id)
                else:
                    print("Invalid username or password.")
            else:
                print("Delete operation cancelled.")
        elif choice == '4':
            print("Goodbye!")
            return
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
